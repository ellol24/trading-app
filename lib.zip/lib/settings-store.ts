export type PlatformSettings = {
  tradingEnabled: boolean
  withdrawalsEnabled: boolean
  depositsEnabled: boolean
  registrationsEnabled: boolean
  maintenanceMode: boolean
  broadcastMessage: string
  kycRequired: boolean

  // New: Welcome Bonus controls
  welcomeBonusEnabled: boolean
  welcomeBonusAmount: number
}

const STORAGE_KEY = "platform_settings_v1"

type Subscriber = () => void
const subs = new Set<Subscriber>()
function notify() {
  subs.forEach((fn) => {
    try {
      fn()
    } catch (e) {
      console.error("settings-store subscriber failed", e)
    }
  })
}

export function subscribeSettings(cb: Subscriber) {
  subs.add(cb)
  return () => subs.delete(cb)
}

const defaultSettings: PlatformSettings = {
  tradingEnabled: true,
  withdrawalsEnabled: true,
  depositsEnabled: true,
  registrationsEnabled: true,
  maintenanceMode: false,
  broadcastMessage: "Welcome to Xspy-trader! We are constantly improving our platform.",
  kycRequired: false,

  // Defaults for welcome bonus
  welcomeBonusEnabled: false,
  welcomeBonusAmount: 50, // USD equivalent (adjust as needed)
}

function safeNumber(n: unknown, fallback: number): number {
  const v = typeof n === "number" ? n : Number(n)
  return Number.isFinite(v) ? v : fallback
}

function read(): PlatformSettings {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (!raw) return defaultSettings
    const parsed = JSON.parse(raw)
    // Coerce numeric fields in case older data stored them as strings
    return {
      ...defaultSettings,
      ...(parsed || {}),
      welcomeBonusAmount: safeNumber(parsed?.welcomeBonusAmount, defaultSettings.welcomeBonusAmount),
    }
  } catch {
    return defaultSettings
  }
}

function write(settings: PlatformSettings) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(settings))
  notify()
}

export function getSettings(): PlatformSettings {
  return read()
}

export function updateSetting<K extends keyof PlatformSettings>(key: K, value: PlatformSettings[K]) {
  const current = read()
  const next = { ...current, [key]: value }
  write(next)
  return next
}

export function setBroadcastMessage(message: string) {
  const current = read()
  write({ ...current, broadcastMessage: message })
}
