// lib/auth-actions.ts
"use server";

import { createClient } from "@/lib/supabase/server";
import { headers } from "next/headers";

// ✅ تعريف ActionState
export type ActionState = {
  error?: string;
  success?: string;
};

// 🟢 تسجيل حساب جديد
export async function signUp(
  prevState: ActionState,
  formData: FormData
): Promise<ActionState> {
  const supabase = createClient();

  const fullName = formData.get("fullName") as string;
  const email = formData.get("email") as string;
  const password = formData.get("password") as string;
  const referralCodeUsed = (formData.get("referralCode") as string) || null;

  // 🔹 جلب IP المستخدم
  const ip = (headers().get("x-forwarded-for") ?? "unknown").split(",")[0];

  // إنشاء الحساب في Supabase Auth + meta data
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
    options: {
      data: {
        full_name: fullName,
        referral_code_used: referralCodeUsed,
        ip_address: ip,
      },
    },
  });

  if (error) {
    return { error: error.message };
  }

  // ✅ ما نعمل insert يدوي → التريجر بيهتم
  return { success: "Account created successfully!" };
}

// 🟢 تسجيل الدخول
export async function signIn(
  prevState: ActionState,
  formData: FormData
): Promise<ActionState> {
  const supabase = createClient();

  const email = formData.get("email") as string;
  const password = formData.get("password") as string;

  // 🔹 جلب IP المستخدم
  const ip = (headers().get("x-forwarded-for") ?? "unknown").split(",")[0];

  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password,
  });

  if (error) {
    return { error: error.message };
  }

  // تحديث آخر IP عند تسجيل الدخول
  if (data?.user) {
    await supabase
      .from("user_profiles")
      .update({ ip_address: ip })
      .eq("uid", data.user.id);
  }

  return { success: "Logged in successfully!" };
}

// 🟢 تسجيل الخروج
export async function signOut(): Promise<ActionState> {
  const supabase = createClient();
  const { error } = await supabase.auth.signOut();

  if (error) {
    return { error: error.message };
  }

  return { success: "Logged out successfully!" };
}
