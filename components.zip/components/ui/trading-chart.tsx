"use client"

import { useCallback, useEffect, useRef, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { TrendingUp, TrendingDown, BarChart3 } from 'lucide-react'
import { marketDataService, type MarketData, type CandlestickData } from "@/lib/market-data"

type Timeframe = "1m" | "5m" | "15m" | "1h"

interface TradingChartProps {
  symbol: string
  onTrade?: (type: "CALL" | "PUT", amount: number) => void
}

const TF_TO_MS: Record<Timeframe, number> = {
  "1m": 60_000,
  "5m": 300_000,
  "15m": 900_000,
  "1h": 3_600_000,
}

const MAX_CANDLES = 120

export function TradingChart({ symbol, onTrade }: TradingChartProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const containerRef = useRef<HTMLDivElement>(null)

  const [marketData, setMarketData] = useState<MarketData | null>(null)
  const [candles, setCandles] = useState<CandlestickData[]>([])
  const candlesRef = useRef<CandlestickData[]>([])
  const [timeframe, setTimeframe] = useState<Timeframe>("5m")
  const [hover, setHover] = useState<{ x: number; y: number } | null>(null)
  const [isLive, setIsLive] = useState(true)

  const tfMs = TF_TO_MS[timeframe]

  useEffect(() => {
    candlesRef.current = candles
  }, [candles])

  // Subscribe to ticks and seed candles on symbol/timeframe change
  useEffect(() => {
    let unsubscribe: (() => void) | undefined

    // Seed initial candles from the service
    const seeded = marketDataService.generateCandlestickData(symbol)
    const initial = seeded.length > MAX_CANDLES ? seeded.slice(-MAX_CANDLES) : seeded
    setCandles(initial)
    candlesRef.current = initial

    unsubscribe = marketDataService.subscribe(symbol, (data) => {
      setMarketData(data)
      foldPriceIntoCandles(data.price, Date.now())
    })

    return () => {
      unsubscribe?.()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [symbol, timeframe])

  // Ensure redraw on resize
  useEffect(() => {
    const handler = () => draw()
    window.addEventListener("resize", handler)
    return () => window.removeEventListener("resize", handler)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [candles, marketData, timeframe, hover])

  const foldPriceIntoCandles = useCallback(
    (price: number, nowTs: number) => {
      setIsLive(true)
      setCandles((prev) => {
        const list = prev.length ? [...prev] : []
        const bucketStart = Math.floor(nowTs / tfMs) * tfMs

        if (list.length === 0) {
          return [
            {
              timestamp: bucketStart,
              open: price,
              high: price,
              low: price,
              close: price,
              volume: Math.floor(Math.random() * 100000),
            },
          ]
        }

        const last = list[list.length - 1]
        if (last.timestamp < bucketStart) {
          // Start a new candle
          list.push({
            timestamp: bucketStart,
            open: last.close,
            high: price,
            low: price,
            close: price,
            volume: Math.floor(Math.random() * 100000),
          })
          if (list.length > MAX_CANDLES) list.shift()
        } else {
          // Update active candle
          last.high = Math.max(last.high, price)
          last.low = Math.min(last.low, price)
          last.close = price
          list[list.length - 1] = { ...last }
        }
        return list
      })
    },
    [tfMs]
  )

  const draw = useCallback(() => {
    const canvas = canvasRef.current
    const container = containerRef.current
    if (!canvas || !container) return
    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const rect = container.getBoundingClientRect()
    const dpr = window.devicePixelRatio || 1
    const height = 360
    canvas.width = Math.floor(rect.width * dpr)
    canvas.height = Math.floor(height * dpr)
    canvas.style.width = `${rect.width}px`
    canvas.style.height = `${height}px`
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0)

    const width = rect.width
    const paddingLeft = 56 // extra space for y-axis labels
    const paddingRight = 16
    const paddingTop = 40
    const paddingBottom = 36
    const chartW = width - paddingLeft - paddingRight
    const chartH = height - paddingTop - paddingBottom

    // Background
    ctx.clearRect(0, 0, width, height)
    ctx.fillStyle = "rgba(15,23,42,0.45)"
    ctx.fillRect(0, 0, width, height)

    const data = candlesRef.current
    if (!data.length) return

    // Range
    const highs = data.map((d) => d.high)
    const lows = data.map((d) => d.low)
    const minPrice = Math.min(...lows)
    const maxPrice = Math.max(...highs)
    const range = Math.max(1e-8, maxPrice - minPrice)
    const pxY = (p: number) => paddingTop + chartH - ((p - minPrice) / range) * chartH

    // Grid + Y-axis labels
    const hLines = 6
    ctx.strokeStyle = "rgba(148,163,184,0.15)"
    ctx.lineWidth = 1
    ctx.font = "12px Inter, ui-sans-serif, system-ui, -apple-system, Segoe UI"
    ctx.fillStyle = "rgba(203,213,225,0.9)"
    ctx.textAlign = "right"
    ctx.textBaseline = "middle"

    for (let i = 0; i <= hLines; i++) {
      const y = paddingTop + (chartH / hLines) * i
      // grid line
      ctx.beginPath()
      ctx.moveTo(paddingLeft, y)
      ctx.lineTo(width - paddingRight, y)
      ctx.stroke()
      // label
      const price = maxPrice - (range / hLines) * i
      const decimals = range < 1 ? 4 : range < 10 ? 3 : 2
      ctx.fillText(price.toFixed(decimals), paddingLeft - 8, y)
    }

    // Vertical grid
    const vLines = 10
    for (let i = 0; i <= vLines; i++) {
      const x = paddingLeft + (chartW / vLines) * i
      ctx.beginPath()
      ctx.moveTo(x, paddingTop)
      ctx.lineTo(x, paddingTop + chartH)
      ctx.stroke()
    }

    // Candles
    const slot = chartW / data.length
    const bodyW = Math.max(2, slot * 0.6)
    for (let i = 0; i < data.length; i++) {
      const c = data[i]
      const cx = paddingLeft + slot * i + (slot - bodyW) / 2
      const openY = pxY(c.open)
      const closeY = pxY(c.close)
      const highY = pxY(c.high)
      const lowY = pxY(c.low)
      const green = c.close >= c.open

      // Wick
      ctx.strokeStyle = green ? "#10b981" : "#ef4444"
      ctx.beginPath()
      ctx.moveTo(cx + bodyW / 2, highY)
      ctx.lineTo(cx + bodyW / 2, lowY)
      ctx.stroke()

      // Body
      ctx.fillStyle = green ? "#10b981" : "#ef4444"
      const top = Math.min(openY, closeY)
      const h = Math.max(1, Math.abs(closeY - openY))
      ctx.fillRect(cx, top, bodyW, h)
    }

    // Last price line + label
    if (marketData) {
      const y = pxY(marketData.price)
      ctx.setLineDash([4, 4])
      ctx.strokeStyle = "rgba(59,130,246,0.5)"
      ctx.beginPath()
      ctx.moveTo(paddingLeft, y)
      ctx.lineTo(width - paddingRight, y)
      ctx.stroke()
      ctx.setLineDash([])

      const label = `${marketData.price}`
      ctx.font = "12px Inter, ui-sans-serif, system-ui, -apple-system, Segoe UI"
      const metricsPad = 6
      const textW = ctx.measureText(label).width
      const boxW = textW + metricsPad * 2 + 10
      const boxH = 22
      ctx.fillStyle = "#1f2937"
      ctx.fillRect(width - paddingRight - boxW, y - boxH / 2, boxW, boxH)
      ctx.fillStyle = "#93c5fd"
      ctx.fillText(label, width - paddingRight - textW - metricsPad - 6, y + 1)
      ctx.beginPath()
      ctx.arc(width - paddingRight - 8, y, 3, 0, Math.PI * 2)
      ctx.fill()
    }

    // Crosshair + tooltip
    if (hover) {
      const idx = Math.min(
        data.length - 1,
        Math.max(0, Math.floor((hover.x - paddingLeft) / (chartW / data.length)))
      )
      const c = data[idx]
      const vx = paddingLeft + (chartW / data.length) * idx + (chartW / data.length) / 2

      // Vertical
      ctx.strokeStyle = "rgba(148,163,184,0.25)"
      ctx.beginPath()
      ctx.moveTo(vx, paddingTop)
      ctx.lineTo(vx, paddingTop + chartH)
      ctx.stroke()

      // Tooltip
      const tooltip = `O ${c.open.toFixed(4)}  H ${c.high.toFixed(4)}  L ${c.low.toFixed(
        4
      )}  C ${c.close.toFixed(4)}`
      ctx.font = "12px Inter, ui-sans-serif, system-ui, -apple-system, Segoe UI"
      const tW = ctx.measureText(tooltip).width
      const bx = Math.min(Math.max(paddingLeft, vx - tW / 2 - 10), width - paddingRight - tW - 20)
      const by = paddingTop + 10
      ctx.fillStyle = "rgba(2,6,23,0.85)"
      ctx.fillRect(bx, by, tW + 20, 24)
      ctx.fillStyle = "#e5e7eb"
      ctx.fillText(tooltip, bx + 10, by + 16)
    }
  }, [marketData, timeframe, hover])

  useEffect(() => {
    draw()
  }, [draw, candles, marketData, hover, timeframe])

  const onMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const rect = (e.target as HTMLCanvasElement).getBoundingClientRect()
    setHover({ x: e.clientX - rect.left, y: e.clientY - rect.top })
  }
  const onLeave = () => setHover(null)

  const handleTrade = (type: "CALL" | "PUT") => {
    if (onTrade) onTrade(type, 100)
  }

  if (!marketData) {
    return (
      <Card className="trading-card">
        <CardContent className="flex items-center justify-center h-96">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-400" />
        </CardContent>
      </Card>
    )
  }

  const changeDir = marketData.trend === "up"

  return (
    <Card className="trading-card">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center space-x-2 text-white light:text-gray-900">
            <BarChart3 className="w-5 h-5" />
            <span>{symbol}</span>
          </CardTitle>
          <div className="flex items-center gap-2">
            <Badge variant={changeDir ? "default" : "destructive"} className="flex items-center">
              {changeDir ? (
                <TrendingUp className="w-3 h-3 mr-1" />
              ) : (
                <TrendingDown className="w-3 h-3 mr-1" />
              )}
              {marketData.changePercent > 0 ? "+" : ""}
              {marketData.changePercent}%
            </Badge>
            <Badge variant="outline" className="text-xs border-blue-500/40 text-blue-300 bg-blue-500/10">
              <span className="relative flex items-center">
                <span className={`w-2 h-2 rounded-full mr-1 ${isLive ? "bg-green-400 animate-pulse" : "bg-gray-400"}`} />
                Live
              </span>
            </Badge>
          </div>
        </div>

        <div className="flex items-center justify-between">
          <div>
            <div className="text-3xl font-bold text-white light:text-gray-900">{marketData.price}</div>
            <div className={`text-sm ${changeDir ? "text-green-400" : "text-red-400"}`}>
              {marketData.change > 0 ? "+" : ""}
              {marketData.change}
            </div>
          </div>

          <div className="flex space-x-1">
            {(["1m", "5m", "15m", "1h"] as const).map((tf) => (
              <Button
                key={tf}
                variant={timeframe === tf ? "default" : "outline"}
                size="sm"
                onClick={() => setTimeframe(tf)}
                className="text-xs"
              >
                {tf}
              </Button>
            ))}
          </div>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        <div ref={containerRef} className="relative w-full">
          <canvas
            ref={canvasRef}
            className="w-full h-[360px] bg-slate-800/20 light:bg-gray-100/20 rounded-lg"
            style={{ width: "100%", height: "360px" }}
            onMouseMove={onMove}
            onMouseLeave={onLeave}
          />
        </div>

        <div className="grid grid-cols-3 gap-4 text-sm">
          <div>
            <div className="text-gray-400 light:text-gray-600">24h High</div>
            <div className="font-semibold text-white light:text-gray-900">{marketData.high24h}</div>
          </div>
          <div>
            <div className="text-gray-400 light:text-gray-600">24h Low</div>
            <div className="font-semibold text-white light:text-gray-900">{marketData.low24h}</div>
          </div>
          <div>
            <div className="text-gray-400 light:text-gray-600">Volume</div>
            <div className="font-semibold text-white light:text-gray-900">{(marketData.volume / 1_000_000).toFixed(1)}M</div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <Button onClick={() => handleTrade("CALL")} className="h-12 bg-green-600 hover:bg-green-700 text-white">
            <TrendingUp className="w-4 h-4 mr-2" />
            CALL (UP)
          </Button>
          <Button onClick={() => handleTrade("PUT")} className="h-12 bg-red-600 hover:bg-red-700 text-white">
            <TrendingDown className="w-4 h-4 mr-2" />
            PUT (DOWN)
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
