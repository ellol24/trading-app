import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Skeleton } from "@/components/ui/skeleton"

export default function ReferralsLoading() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 pb-20">
      <div className="p-6 space-y-6">
        <div className="max-w-6xl mx-auto space-y-6">
          {/* Header Skeleton */}
          <div className="flex items-center justify-between">
            <div>
              <Skeleton className="h-8 w-48 bg-slate-700" />
              <Skeleton className="h-4 w-64 mt-2 bg-slate-700" />
            </div>
            <Skeleton className="h-8 w-32 bg-slate-700" />
          </div>

          {/* Stats Cards Skeleton */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {Array.from({ length: 4 }).map((_, i) => (
              <Card key={i} className="bg-slate-800/50 border-slate-700">
                <CardContent className="p-4">
                  <div className="flex items-center space-x-3">
                    <Skeleton className="h-12 w-12 rounded-lg bg-slate-600" />
                    <div className="space-y-2">
                      <Skeleton className="h-4 w-20 bg-slate-600" />
                      <Skeleton className="h-6 w-16 bg-slate-600" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Referral Link Card Skeleton */}
          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader>
              <Skeleton className="h-6 w-40 bg-slate-600" />
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex space-x-2">
                <Skeleton className="h-10 flex-1 bg-slate-600" />
                <Skeleton className="h-10 w-10 bg-slate-600" />
                <Skeleton className="h-10 w-10 bg-slate-600" />
              </div>
              <Skeleton className="h-20 w-full bg-slate-600" />
            </CardContent>
          </Card>

          {/* Tabs Skeleton */}
          <div className="space-y-4">
            <Skeleton className="h-10 w-full bg-slate-700" />
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <Skeleton className="h-6 w-48 bg-slate-600" />
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {Array.from({ length: 3 }).map((_, i) => (
                    <Skeleton key={i} className="h-16 w-full bg-slate-600" />
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
