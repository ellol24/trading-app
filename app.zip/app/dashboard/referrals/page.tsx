import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import ReferralsPage from "./ReferralsPage";

export default async function Referrals() {
  const supabase = createClient();

  // ✅ جلب المستخدم من السيرفر (عن طريق الكوكيز)
  const {
    data: { user },
    error,
  } = await supabase.auth.getUser();

  if (!user) {
    redirect("/auth/login"); // لو مافيش مستخدم رجّعه للّوج إن
  }

  // ✅ جلب بروفايل المستخدم من جدول user_profiles
  const { data: profile, error: profileError } = await supabase
    .from("user_profiles")
    .select("*")
    .eq("uid", user.id)
    .single();

  if (profileError) {
    console.error("Error fetching profile:", profileError.message);
  }

  return <ReferralsPage user={user} profile={profile} />;
}
