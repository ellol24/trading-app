"use client";


import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Users,
  Copy,
  Share,
  DollarSign,
  Award,
  Trophy,
  Target,
  TrendingUp,
  UserPlus,
  Gift,
  Star,
  Crown,
  Medal,
} from "lucide-react";
import { toast } from "sonner";

/* ----- Types ----- */
type ReferralStats = {
  totalInvites: number
  activeReferrals: number
  totalEarnings: number
  thisMonthEarnings: number
  commissionRate: number
  lifetimeCommission: number
}

type ReferralHistory = {
  id: string
  username: string
  email: string
  joinDate: string
  status: string
  totalDeposits: number
  yourCommission: number
  level: number
}

type TopReferrer = {
  rank: number
  username: string
  referrals: number
  earnings: number
  avatar: string
  isCurrentUser?: boolean
}

type CommissionLevel = {
  level: number
  users: number
  commission: number
  earnings: number
}

type ReferralsPageProps = {
  user: any
  profile: any
}

/* ----- Component ----- */
export default function ReferralsPage({ user, profile }: { user: any; profile: any }) {
  const [referralLink, setReferralLink] = useState("");
  const [activeTab, setActiveTab] = useState("overview");

  const [stats, setStats] = useState<ReferralStats>({
    totalInvites: 0,
    activeReferrals: 0,
    totalEarnings: 0,
    thisMonthEarnings: 0,
    commissionRate: 10,
    lifetimeCommission: 0,
  });
  const [history, setHistory] = useState<ReferralHistory[]>([]);
  const [topReferrers, setTopReferrers] = useState<TopReferrer[]>([]);
  const [commissionLevels, setCommissionLevels] = useState<CommissionLevel[]>([]);
  const [loading, setLoading] = useState(true);

   useEffect(() => {
    async function fetchData() {
      setLoading(true);
      try {
        // 1) جلب المستخدم الحالي
        const {
          data: { user },
          error: userErr,
        } = await supabase.auth.getUser();
        if (userErr) {
          console.error("Auth getUser error:", userErr);
          setLoading(false);
          return;
        }
        if (!user) {
          console.warn("No user logged in");
          setLoading(false);
          return;
        }


       // 2) جلب referral_code من user_profiles (إذا موجود)
        const { data: profile, error: profileErr } = await supabase
          .from("user_profiles")
          .select("referral_code")
          .eq("uid", user.id)
          .single();

        if (profileErr && profileErr.code !== "PGRST116") {
          // PGRST116 = no rows? ignore if no row
          console.warn("profile fetch error:", profileErr);
        }
        const code = profile?.referral_code ?? user.id;
        setReferralLink(`https://xspy-trader.com/ref/${code}`);

        // 3) جلب كل الإحالات التي قام بها هذا المستخدم (referrer_id = user.id)
        const { data: referrals, error: referralsErr } = await supabase
          .from("referrals")
          .select("id, referred_id, referral_code, created_at, status, level")
          .eq("referrer_id", user.id)
          .order("created_at", { ascending: false });

        if (referralsErr) {
          console.error("Error fetching referrals:", referralsErr);
        }

        // إذا لم توجد إحالات، نفرّغ القوائم والإحصائيات
        if (!referrals || referrals.length === 0) {
          setHistory([]);
          // لا نوقف هنا لأن نريد بيانات العمولات (قد تكون صفر)
        }

        // 4) جلب الملفات الشخصية للمحالين (user_profiles) دفعة واحدة
        const referredIds = (referrals || []).map((r: any) => r.referred_id).filter(Boolean);
        let profilesMap: Record<string, any> = {};
        if (referredIds.length > 0) {
          const { data: referredProfiles, error: profErr } = await supabase
            .from("user_profiles")
            .select("uid, full_name, email, referral_code")
            .in("uid", referredIds);

          if (profErr) {
            console.error("Error fetching referred profiles:", profErr);
          } else {
            referredProfiles?.forEach((p: any) => {
              profilesMap[p.uid] = p;
            });
          }
        }

         // 5) جلب عمولات الإحالات التي تخص إحالات هذا المستخدم (join عبر referrals)
        const { data: commissionsForUser, error: commErr } = await supabase
          .from("referral_commissions")
          .select("id, commission_amount, created_at, referral_id, level, referrals!inner(referrer_id)")
          .eq("referrals.referrer_id", user.id);

        if (commErr) {
          console.error("Error fetching commissions for user:", commErr);
        }

        // نحسب مجموع العمولة لكل referral_id
        const commissionsMap: Record<string, number> = {};
        (commissionsForUser || []).forEach((c: any) => {
          commissionsMap[c.referral_id] = (commissionsMap[c.referral_id] || 0) + Number(c.commission_amount || 0);
        });

       
        // 6) بسّط التاريخ واختر القيم النهائية لقائمة التاريخ (history)
        const formattedHistory: ReferralHistory[] = (referrals || []).map((r: any) => {
          const p = profilesMap[r.referred_id] || {};
          return {
            id: r.id,
            referred_uid: r.referred_id,
            username: p.full_name || "Unnamed",
            email: p.email || "No email",
            referral_code: p.referral_code,
            joinDate: r.created_at,
            status: r.status === "active" ? "Active" : "Inactive",
            totalDeposits: 0, // ربط لاحق بجدول deposits إن وُجد
            yourCommission: commissionsMap[r.id] || 0,
            level: r.level ?? 1,
          };
        });

        setHistory(formattedHistory);

        // 7) إحصائيات سريعة مبنية عى history + commissionsForUser
        const totalInvites = formattedHistory.length;
        const activeReferrals = formattedHistory.filter((h) => h.status === "Active").length;
        const totalEarnings = (commissionsForUser || []).reduce((s: number, c: any) => s + Number(c.commission_amount || 0), 0);
        const thisMonthIndex = new Date().getMonth();
        const thisMonthEarnings =
          (commissionsForUser || []).filter((c) => new Date(c.created_at).getMonth() === thisMonthIndex)
            .reduce((s: number, c: any) => s + Number(c.commission_amount || 0), 0) || 0;

        setStats({
          totalInvites,
          activeReferrals,
          totalEarnings,
          thisMonthEarnings,
          commissionRate: 10,
          lifetimeCommission: totalEarnings,
        });

         // 8) أفضل المحيلين (Leaderboard) — نجلب كل عمولات النظام ونجمّع بحسب referrer_id
        const { data: allCommissions, error: allCommErr } = await supabase
          .from("referral_commissions")
          .select("commission_amount, referral_id, created_at, referrals(referrer_id)")
          .order("created_at", { ascending: false });

        if (allCommErr) console.error("allCommissions err:", allCommErr);

        // نجمع أرباح بحسب referrer_id
        const topMap: Record<string, { earnings: number; referrals: number }> = {};
        // نحتاج لمطابقة كل referral_commission -> referral to get referrer_id
        // لاحظ: أعلاه استعلمنا مع relation referrals(referrer_id) لذلك كل سجل قد يحتوي على referrals.referrer_id
        (allCommissions || []).forEach((c: any) => {
          const rid = c.referrals?.referrer_id;
          if (!rid) return;
          if (!topMap[rid]) topMap[rid] = { earnings: 0, referrals: 0 };
          topMap[rid].earnings += Number(c.commission_amount || 0);
          topMap[rid].referrals += 1;
        });

        // لنحصل على أسمائهم نطلب ملفاتهم (user_profiles) دفعة واحدة
        const topIds = Object.keys(topMap);
        let topProfiles: Record<string, any> = {};
        if (topIds.length > 0) {
          const { data: tp, error: tpErr } = await supabase
            .from("user_profiles")
            .select("uid, full_name")
            .in("uid", topIds);
          if (tpErr) console.error("top profiles err:", tpErr);
          tp?.forEach((p: any) => (topProfiles[p.uid] = p));
        }

        const top = Object.entries(topMap)
          .map(([id, d], idx) => ({
            rank: idx + 1,
            username: topProfiles[id]?.full_name || "Unknown",
            referrals: d.referrals,
            earnings: d.earnings,
            avatar: idx === 0 ? "👑" : idx === 1 ? "🏆" : idx === 2 ? "⭐" : "💎",
            isCurrentUser: id === user.id,
          }))
          .sort((a, b) => b.earnings - a.earnings)
          .slice(0, 10);

        setTopReferrers(top);

        // 9) مستويات العمولة — نبني من history
        const levelsMap: Record<number, { users: number; earnings: number }> = {};
        formattedHistory.forEach((h) => {
          const lvl = Number(h.level || 1);
          if (!levelsMap[lvl]) levelsMap[lvl] = { users: 0, earnings: 0 };
          levelsMap[lvl].users++;
          levelsMap[lvl].earnings += Number(h.yourCommission || 0);
        });

        const levelsArr: CommissionLevel[] = Object.entries(levelsMap).map(([level, d]) => ({
          level: Number(level),
          users: d.users,
          commission: Number(level) === 1 ? 10 : Number(level) === 2 ? 5 : 2,
          earnings: d.earnings,
        }));
        setCommissionLevels(levelsArr);

        console.log("Referrals loaded:", { formattedHistory, stats: { totalInvites, activeReferrals, totalEarnings, thisMonthEarnings }, top });
      } catch (err) {
        console.error("Unexpected fetchData error:", err);
      } finally {
        setLoading(false);
      }
    }

    fetchData();
  }, []);

   // نسخ الرابط
  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text || "");
      toast.success("Copied to clipboard!");
    } catch (e) {
      toast.error("Failed to copy");
    }
  };

  // مشاركة الرابط
  const shareReferralLink = async () => {
    if (!referralLink) {
      toast.error("Referral link not ready");
      return;
    }
    if (navigator.share) {
      try {
        await navigator.share({
          title: "Join Xspy-trader",
          text: "Earn lifetime commissions by inviting traders.",
          url: referralLink,
        });
      } catch {
        copyToClipboard(referralLink);
      }
    } else {
      copyToClipboard(referralLink);
    }
  };


   /* ===== واجهة المستخدم (نفس تصميمك مع بيانات حقيقية) ===== */
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 pb-20">
      <div className="p-6 space-y-6">
        <div className="max-w-6xl mx-auto space-y-6">
          {/* Header */}
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-white">Professional Referral Program</h1>
              <p className="text-gray-400 mt-1">Earn lifetime commissions by inviting traders to Xspy-trader</p>
            </div>
            <Badge variant="outline" className="text-green-400 border-green-400 bg-green-400/10 px-4 py-2">
              <Trophy className="w-4 h-4 mr-2" />
              {stats.commissionRate}% Commission Rate
            </Badge>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
              <CardContent className="p-4">
                <div className="flex items-center space-x-3">
                  <div className="p-3 rounded-lg bg-blue-500/20">
                    <Users className="h-6 w-6 text-blue-400" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-400">Total Referrals</p>
                    <p className="text-2xl font-bold text-white">{stats.totalInvites}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
              <CardContent className="p-4">
                <div className="flex items-center space-x-3">
                  <div className="p-3 rounded-lg bg-green-500/20">
                    <Target className="h-6 w-6 text-green-400" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-400">Active Traders</p>
                    <p className="text-2xl font-bold text-white">{stats.activeReferrals}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
              <CardContent className="p-4">
                <div className="flex items-center space-x-3">
                  <div className="p-3 rounded-lg bg-purple-500/20">
                    <DollarSign className="h-6 w-6 text-purple-400" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-400">This Month</p>
                    <p className="text-2xl font-bold text-white">${stats.thisMonthEarnings.toFixed(2)}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
              <CardContent className="p-4">
                <div className="flex items-center space-x-3">
                  <div className="p-3 rounded-lg bg-orange-500/20">
                    <TrendingUp className="h-6 w-6 text-orange-400" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-400">Total Earned</p>
                    <p className="text-2xl font-bold text-white">${stats.lifetimeCommission.toFixed(2)}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>


          {/* Referral Link */}
          <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-white flex items-center space-x-2">
                <Share className="h-5 w-5" />
                <span>Your Professional Referral Link</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex space-x-2">
                <Input
                  value={referralLink}
                  readOnly
                  className="flex-1 bg-slate-700/50 border-slate-600 text-white font-mono text-sm"
                />
                <Button onClick={() => copyToClipboard(referralLink)} size="icon" className="bg-blue-600 hover:bg-blue-700" title="Copy Link">
                  <Copy className="h-4 w-4" />
                </Button>
                <Button onClick={shareReferralLink} size="icon" className="bg-green-600 hover:bg-green-700" title="Share Link">
                  <Share className="h-4 w-4" />
                </Button>
              </div>
              <div className="p-4 bg-slate-700/30 rounded-lg border border-slate-600">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                  <div className="flex items-center space-x-2">
                    <Gift className="h-4 w-4 text-green-400" />
                    <span className="text-gray-300">
                      <strong className="text-white">10% lifetime commission</strong> on all trading activity
                    </span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Trophy className="h-4 w-4 text-yellow-400" />
                    <span className="text-gray-300">
                      <strong className="text-white">Professional rewards</strong> with guaranteed payouts
                    </span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <TrendingUp className="h-4 w-4 text-blue-400" />
                    <span className="text-gray-300">
                      <strong className="text-white">Instant earnings</strong> credited to your balance
                    </span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Tabs (Overview / Network / Leaderboard / History) */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-4 bg-slate-800/50 border-slate-700">
              <TabsTrigger value="overview" className="data-[state=active]:bg-blue-600">Overview</TabsTrigger>
              <TabsTrigger value="network" className="data-[state=active]:bg-blue-600">Network</TabsTrigger>
              <TabsTrigger value="leaderboard" className="data-[state=active]:bg-blue-600">Leaderboard</TabsTrigger>
              <TabsTrigger value="history" className="data-[state=active]:bg-blue-600">History</TabsTrigger>
            </TabsList>

            {/* Overview */}
            <TabsContent value="overview" className="space-y-6">
              <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="text-white flex items-center space-x-2">
                    <Award className="h-5 w-5" />
                    <span>Professional Commission Structure</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {commissionLevels.length === 0 ? (
                      <div className="col-span-3 text-gray-400">No commission tiers yet.</div>
                    ) : (
                      commissionLevels.map((level) => (
                        <div key={level.level} className="p-4 rounded-lg bg-slate-700/30 border border-slate-600">
                          <div className="flex items-center justify-between mb-3">
                            <span className="text-lg font-semibold text-white">Tier {level.level}</span>
                            <Badge variant="outline" className="text-green-400 border-green-400">{level.commission}%</Badge>
                          </div>
                          <div className="space-y-2 text-sm">
                            <div className="flex justify-between">
                              <span className="text-gray-400">Active Traders:</span>
                              <span className="text-white font-medium">{level.users}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-400">Total Earnings:</span>
                              <span className="text-green-400 font-medium">${level.earnings.toFixed(2)}</span>
                            </div>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>


            {/* Network (dummy visualization) */}
            <TabsContent value="network" className="space-y-6">
              <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="text-white">Your Professional Trading Network</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-gray-300">Network visualization coming soon (uses history data).</div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Leaderboard */}
            <TabsContent value="leaderboard" className="space-y-6">
              <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2 text-white"><Trophy className="h-5 w-5" /><span>Top Professional Referrers</span></CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {topReferrers.length === 0 ? (
                      <div className="text-gray-400">No leaderboard data yet.</div>
                    ) : (
                      topReferrers.map((referrer) => (
                        <div key={referrer.rank} className={`flex items-center justify-between p-4 rounded-lg ${referrer.isCurrentUser ? "bg-blue-500/10" : "bg-slate-700/30"} border border-slate-600`}>
                          <div className="flex items-center space-x-4">
                            <div className="w-12 h-12 rounded-full flex items-center justify-center text-white font-bold text-lg bg-gradient-to-r from-slate-500 to-slate-700">
                              {referrer.rank <= 3 ? (referrer.rank === 1 ? <Crown className="h-6 w-6" /> : referrer.rank === 2 ? <Medal className="h-6 w-6" /> : <Star className="h-6 w-6" />) : referrer.rank}
                            </div>
                            <div>
                              <div className="flex items-center space-x-2">
                                <p className="font-semibold text-white text-lg">{referrer.username}</p>
                                <span className="text-xl">{referrer.avatar}</span>
                                {referrer.isCurrentUser && <Badge variant="outline" className="text-blue-400 border-blue-400">You</Badge>}
                              </div>
                              <p className="text-sm text-gray-400">{referrer.referrals} referrals</p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="font-bold text-green-400 text-lg">${referrer.earnings.toFixed(2)}</p>
                            <p className="text-xs text-gray-400">Total earned</p>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* History */}
            <TabsContent value="history" className="space-y-6">
              <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="text-white">Professional Referral History</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {loading ? (
                      <div className="text-gray-400">Loading...</div>
                    ) : history.length === 0 ? (
                      <div className="text-gray-400">No referrals yet.</div>
                    ) : (
                      history.map((ref) => (
                        <div key={ref.id} className="flex items-center justify-between p-4 rounded-lg bg-slate-700/30 border border-slate-600">
                          <div className="flex items-center space-x-4">
                            <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white font-bold">
                              {ref.username?.charAt(0)?.toUpperCase() || "U"}
                            </div>
                            <div>
                              <p className="font-semibold text-white">{ref.username}</p>
                              <p className="text-sm text-gray-400">{ref.email}</p>
                              <p className="text-xs text-gray-500">Joined: {new Date(ref.joinDate).toLocaleString()}</p>
                            </div>
                          </div>
                          <div className="text-right space-y-1">
                            <div className="flex items-center space-x-2">
                              <Badge variant={ref.status === "Active" ? "default" : "secondary"} className={ref.status === "Active" ? "bg-green-600" : "bg-gray-600"}>
                                {ref.status}
                              </Badge>
                              <Badge variant="outline" className="text-blue-400 border-blue-400">T{ref.level}</Badge>
                            </div>
                            <p className="text-sm text-gray-400">Volume: ${ref.totalDeposits}</p>
                            <p className="font-bold text-green-400">+${ref.yourCommission.toFixed(2)}</p>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}