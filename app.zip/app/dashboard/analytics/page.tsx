"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  BarChart3,
  TrendingUp,
  DollarSign,
  Target,
  Activity,
  PieChart,
  LineChart,
  Home,
  Users,
  Package,
  User,
  ArrowUpRight,
  ArrowDownRight,
  Clock,
  Award,
  AlertTriangle,
} from "lucide-react"
import Link from "next/link"

export default function AnalyticsPage() {
  const [timeRange, setTimeRange] = useState("30d")

  const [analyticsData] = useState({
    totalProfit: 15420.75,
    totalLoss: 3280.5,
    netProfit: 12140.25,
    profitMargin: 78.7,
    totalTrades: 234,
    winningTrades: 184,
    losingTrades: 50,
    winRate: 78.6,
    avgWinAmount: 83.8,
    avgLossAmount: 65.6,
    largestWin: 450.0,
    largestLoss: 250.0,
    profitFactor: 4.7,
    sharpeRatio: 2.3,
  })

  const [performanceByAsset] = useState([
    { asset: "EUR/USD", trades: 45, profit: 3250, winRate: 82.2, color: "bg-blue-500" },
    { asset: "BTC/USD", trades: 38, profit: 4100, winRate: 76.3, color: "bg-purple-500" },
    { asset: "GBP/USD", trades: 32, profit: 2180, winRate: 75.0, color: "bg-green-500" },
    { asset: "USD/JPY", trades: 28, profit: 1890, winRate: 71.4, color: "bg-orange-500" },
    { asset: "XAU/USD", trades: 25, profit: 1520, winRate: 68.0, color: "bg-yellow-500" },
  ])

  const [monthlyPerformance] = useState([
    { month: "Jul", profit: 1850, trades: 32, winRate: 75.0 },
    { month: "Aug", profit: 2340, trades: 41, winRate: 78.0 },
    { month: "Sep", profit: 1680, trades: 28, winRate: 71.4 },
    { month: "Oct", profit: 2890, trades: 48, winRate: 81.3 },
    { month: "Nov", profit: 2150, trades: 38, winRate: 76.3 },
    { month: "Dec", profit: 3240, trades: 47, winRate: 83.0 },
  ])

  const [tradingHours] = useState([
    { hour: "00-02", trades: 8, profit: 420, winRate: 62.5 },
    { hour: "02-04", trades: 5, profit: 180, winRate: 60.0 },
    { hour: "04-06", trades: 12, profit: 680, winRate: 75.0 },
    { hour: "06-08", trades: 18, profit: 1240, winRate: 83.3 },
    { hour: "08-10", trades: 25, profit: 1850, winRate: 84.0 },
    { hour: "10-12", trades: 22, profit: 1560, winRate: 81.8 },
    { hour: "12-14", trades: 28, profit: 1980, winRate: 78.6 },
    { hour: "14-16", trades: 32, profit: 2340, winRate: 87.5 },
    { hour: "16-18", trades: 29, profit: 2120, winRate: 82.8 },
    { hour: "18-20", trades: 24, profit: 1680, winRate: 79.2 },
    { hour: "20-22", trades: 19, profit: 1320, winRate: 73.7 },
    { hour: "22-24", trades: 12, profit: 760, winRate: 66.7 },
  ])

  const [riskMetrics] = useState({
    maxDrawdown: 8.5,
    currentDrawdown: 2.1,
    volatility: 12.3,
    riskScore: 6.8,
    calmarRatio: 1.8,
    sortinoRatio: 3.2,
  })

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900">
      <div className="p-6 pb-24">
        <div className="max-w-7xl mx-auto space-y-8">
          {/* Header */}
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-4xl font-bold text-white mb-2">Trading Analytics</h1>
              <p className="text-blue-200">Comprehensive analysis of your trading performance</p>
            </div>
            <div className="flex items-center space-x-4">
              <Select value={timeRange} onValueChange={setTimeRange}>
                <SelectTrigger className="w-32 bg-background/50 border-border/50">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="7d">7 Days</SelectItem>
                  <SelectItem value="30d">30 Days</SelectItem>
                  <SelectItem value="90d">90 Days</SelectItem>
                  <SelectItem value="1y">1 Year</SelectItem>
                </SelectContent>
              </Select>
              <Button className="professional-gradient">
                <BarChart3 className="w-4 h-4 mr-2" />
                Export Report
              </Button>
            </div>
          </div>

          {/* Key Performance Indicators */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="trading-card">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Net Profit</CardTitle>
                <DollarSign className="h-4 w-4 text-green-400" />
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-green-400">${analyticsData.netProfit.toLocaleString()}</div>
                <p className="text-xs text-muted-foreground">Profit Margin: {analyticsData.profitMargin}%</p>
              </CardContent>
            </Card>

            <Card className="trading-card">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Win Rate</CardTitle>
                <Target className="h-4 w-4 text-blue-400" />
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-white">{analyticsData.winRate}%</div>
                <p className="text-xs text-muted-foreground">
                  {analyticsData.winningTrades}/{analyticsData.totalTrades} trades
                </p>
              </CardContent>
            </Card>

            <Card className="trading-card">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Profit Factor</CardTitle>
                <TrendingUp className="h-4 w-4 text-purple-400" />
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-white">{analyticsData.profitFactor}</div>
                <p className="text-xs text-muted-foreground">Sharpe Ratio: {analyticsData.sharpeRatio}</p>
              </CardContent>
            </Card>

            <Card className="trading-card">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Avg Win/Loss</CardTitle>
                <Activity className="h-4 w-4 text-orange-400" />
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-white">${analyticsData.avgWinAmount}</div>
                <p className="text-xs text-red-400">Avg Loss: ${analyticsData.avgLossAmount}</p>
              </CardContent>
            </Card>
          </div>

          {/* Analytics Tabs */}
          <Tabs defaultValue="performance" className="space-y-6">
            <TabsList className="grid w-full grid-cols-4 bg-background/20 backdrop-blur-sm">
              <TabsTrigger
                value="performance"
                className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
              >
                Performance
              </TabsTrigger>
              <TabsTrigger
                value="assets"
                className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
              >
                Asset Analysis
              </TabsTrigger>
              <TabsTrigger
                value="timing"
                className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
              >
                Timing Analysis
              </TabsTrigger>
              <TabsTrigger
                value="risk"
                className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
              >
                Risk Metrics
              </TabsTrigger>
            </TabsList>

            <TabsContent value="performance" className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Monthly Performance */}
                <Card className="trading-card">
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2 text-white">
                      <LineChart className="w-5 h-5" />
                      <span>Monthly Performance Trend</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {monthlyPerformance.map((month, index) => (
                        <div key={index} className="flex items-center justify-between p-4 rounded-lg bg-background/10">
                          <div className="flex items-center space-x-4">
                            <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
                              <span className="text-white font-bold text-sm">{month.month}</span>
                            </div>
                            <div>
                              <p className="font-semibold text-white">${month.profit}</p>
                              <p className="text-sm text-muted-foreground">{month.trades} trades</p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="font-semibold text-green-400">{month.winRate}%</p>
                            <p className="text-xs text-muted-foreground">Win Rate</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                {/* Performance Breakdown */}
                <Card className="trading-card">
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2 text-white">
                      <PieChart className="w-5 h-5" />
                      <span>Profit/Loss Breakdown</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="space-y-4">
                      <div className="flex justify-between items-center p-4 rounded-lg bg-green-500/10 border border-green-500/20">
                        <div className="flex items-center space-x-3">
                          <ArrowUpRight className="w-6 h-6 text-green-400" />
                          <div>
                            <p className="font-semibold text-white">Total Profits</p>
                            <p className="text-sm text-muted-foreground">
                              {analyticsData.winningTrades} winning trades
                            </p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-2xl font-bold text-green-400">
                            ${analyticsData.totalProfit.toLocaleString()}
                          </p>
                          <p className="text-sm text-green-400">Largest: ${analyticsData.largestWin}</p>
                        </div>
                      </div>

                      <div className="flex justify-between items-center p-4 rounded-lg bg-red-500/10 border border-red-500/20">
                        <div className="flex items-center space-x-3">
                          <ArrowDownRight className="w-6 h-6 text-red-400" />
                          <div>
                            <p className="font-semibold text-white">Total Losses</p>
                            <p className="text-sm text-muted-foreground">{analyticsData.losingTrades} losing trades</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-2xl font-bold text-red-400">${analyticsData.totalLoss.toLocaleString()}</p>
                          <p className="text-sm text-red-400">Largest: ${analyticsData.largestLoss}</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="assets" className="space-y-6">
              <Card className="trading-card">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2 text-white">
                    <BarChart3 className="w-5 h-5" />
                    <span>Performance by Trading Asset</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {performanceByAsset.map((asset, index) => (
                      <div key={index} className="p-6 rounded-lg bg-background/10 border border-border/20">
                        <div className="flex items-center justify-between mb-4">
                          <div className="flex items-center space-x-4">
                            <div className={`w-4 h-4 rounded-full ${asset.color}`} />
                            <div>
                              <h3 className="font-bold text-white text-lg">{asset.asset}</h3>
                              <p className="text-sm text-muted-foreground">{asset.trades} trades executed</p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="text-2xl font-bold text-green-400">${asset.profit}</p>
                            <p className="text-sm text-muted-foreground">Total Profit</p>
                          </div>
                        </div>

                        <div className="grid grid-cols-3 gap-4 text-sm">
                          <div>
                            <p className="text-muted-foreground">Win Rate</p>
                            <p className="font-semibold text-white">{asset.winRate}%</p>
                          </div>
                          <div>
                            <p className="text-muted-foreground">Avg Profit/Trade</p>
                            <p className="font-semibold text-green-400">${(asset.profit / asset.trades).toFixed(2)}</p>
                          </div>
                          <div>
                            <p className="text-muted-foreground">Performance</p>
                            <Badge
                              className={`${asset.winRate > 75 ? "bg-green-500/20 text-green-400" : asset.winRate > 65 ? "bg-yellow-500/20 text-yellow-400" : "bg-red-500/20 text-red-400"}`}
                            >
                              {asset.winRate > 75 ? "Excellent" : asset.winRate > 65 ? "Good" : "Needs Improvement"}
                            </Badge>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="timing" className="space-y-6">
              <Card className="trading-card">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2 text-white">
                    <Clock className="w-5 h-5" />
                    <span>Trading Performance by Hour</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {tradingHours.map((hour, index) => (
                      <div key={index} className="p-4 rounded-lg bg-background/10 border border-border/20">
                        <div className="flex items-center justify-between mb-3">
                          <div>
                            <p className="font-semibold text-white">{hour.hour}</p>
                            <p className="text-xs text-muted-foreground">{hour.trades} trades</p>
                          </div>
                          <Badge
                            className={`${hour.winRate > 80 ? "bg-green-500/20 text-green-400" : hour.winRate > 70 ? "bg-yellow-500/20 text-yellow-400" : "bg-red-500/20 text-red-400"}`}
                          >
                            {hour.winRate}%
                          </Badge>
                        </div>
                        <div className="space-y-2">
                          <div className="flex justify-between text-sm">
                            <span className="text-muted-foreground">Profit:</span>
                            <span className="text-green-400">${hour.profit}</span>
                          </div>
                          <div className="w-full bg-background/20 rounded-full h-2">
                            <div
                              className="bg-gradient-to-r from-blue-500 to-purple-500 h-2 rounded-full"
                              style={{ width: `${(hour.winRate / 100) * 100}%` }}
                            />
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="risk" className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card className="trading-card">
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2 text-white">
                      <AlertTriangle className="w-5 h-5" />
                      <span>Risk Assessment</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="space-y-4">
                      <div className="flex justify-between items-center p-4 rounded-lg bg-background/10">
                        <span className="text-muted-foreground">Max Drawdown</span>
                        <div className="text-right">
                          <span className="font-bold text-red-400">{riskMetrics.maxDrawdown}%</span>
                          <p className="text-xs text-muted-foreground">Historical peak</p>
                        </div>
                      </div>

                      <div className="flex justify-between items-center p-4 rounded-lg bg-background/10">
                        <span className="text-muted-foreground">Current Drawdown</span>
                        <div className="text-right">
                          <span className="font-bold text-yellow-400">{riskMetrics.currentDrawdown}%</span>
                          <p className="text-xs text-muted-foreground">From recent peak</p>
                        </div>
                      </div>

                      <div className="flex justify-between items-center p-4 rounded-lg bg-background/10">
                        <span className="text-muted-foreground">Volatility</span>
                        <div className="text-right">
                          <span className="font-bold text-white">{riskMetrics.volatility}%</span>
                          <p className="text-xs text-muted-foreground">Standard deviation</p>
                        </div>
                      </div>

                      <div className="flex justify-between items-center p-4 rounded-lg bg-background/10">
                        <span className="text-muted-foreground">Risk Score</span>
                        <div className="text-right">
                          <span className="font-bold text-orange-400">{riskMetrics.riskScore}/10</span>
                          <Badge className="bg-orange-500/20 text-orange-400 border-orange-400 ml-2">Moderate</Badge>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="trading-card">
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2 text-white">
                      <Award className="w-5 h-5" />
                      <span>Advanced Risk Ratios</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="space-y-4">
                      <div className="p-4 rounded-lg bg-background/10 border border-border/20">
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-muted-foreground">Calmar Ratio</span>
                          <span className="font-bold text-green-400">{riskMetrics.calmarRatio}</span>
                        </div>
                        <p className="text-xs text-muted-foreground">Annual return / Max drawdown. Higher is better.</p>
                      </div>

                      <div className="p-4 rounded-lg bg-background/10 border border-border/20">
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-muted-foreground">Sortino Ratio</span>
                          <span className="font-bold text-blue-400">{riskMetrics.sortinoRatio}</span>
                        </div>
                        <p className="text-xs text-muted-foreground">
                          Risk-adjusted return considering downside deviation only.
                        </p>
                      </div>

                      <div className="p-4 rounded-lg bg-background/10 border border-border/20">
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-muted-foreground">Sharpe Ratio</span>
                          <span className="font-bold text-purple-400">{analyticsData.sharpeRatio}</span>
                        </div>
                        <p className="text-xs text-muted-foreground">Risk-adjusted return vs risk-free rate.</p>
                      </div>

                      <div className="mt-6 p-4 rounded-lg bg-blue-500/10 border border-blue-500/20">
                        <div className="flex items-center space-x-2 mb-2">
                          <AlertTriangle className="w-4 h-4 text-blue-400" />
                          <span className="font-semibold text-blue-400">Risk Assessment</span>
                        </div>
                        <p className="text-sm text-muted-foreground">
                          Your trading profile shows moderate risk with good risk-adjusted returns. Consider
                          diversifying across more time frames to reduce volatility.
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-slate-800/90 backdrop-blur-md border-t border-slate-700 z-50">
        <div className="flex justify-around items-center py-3">
          <Link
            href="/dashboard"
            className="flex flex-col items-center py-2 px-3 rounded-lg text-gray-400 hover:text-white transition-colors"
          >
            <Home className="h-5 w-5 mb-1" />
            <span className="text-xs font-medium">Home</span>
          </Link>
          <Link
            href="/dashboard/trading"
            className="flex flex-col items-center py-2 px-3 rounded-lg text-gray-400 hover:text-white transition-colors"
          >
            <TrendingUp className="h-5 w-5 mb-1" />
            <span className="text-xs font-medium">Trading</span>
          </Link>
          <Link
            href="/dashboard/packages"
            className="flex flex-col items-center py-2 px-3 rounded-lg text-gray-400 hover:text-white transition-colors"
          >
            <Package className="h-5 w-5 mb-1" />
            <span className="text-xs font-medium">Packages</span>
          </Link>
          <Link
            href="/dashboard/referrals"
            className="flex flex-col items-center py-2 px-3 rounded-lg text-gray-400 hover:text-white transition-colors"
          >
            <Users className="h-5 w-5 mb-1" />
            <span className="text-xs font-medium">Referrals</span>
          </Link>
          <Link
            href="/dashboard/profile"
            className="flex flex-col items-center py-2 px-3 rounded-lg text-gray-400 hover:text-white transition-colors"
          >
            <User className="h-5 w-5 mb-1" />
            <span className="text-xs font-medium">Profile</span>
          </Link>
        </div>
      </nav>
    </div>
  )
}
